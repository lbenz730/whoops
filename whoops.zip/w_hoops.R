#############################  Read CSVs #######################################
library(dplyr)
source("helpers.R")
confs <- read.csv("conferences.csv", as.is = T)
y <- read.csv("Results/NCAA_WHoops_Results_2_8_2019.csv", as.is = T)
########################  Data Cleaning ########################################
y <- y %>%
  mutate(scorediff = teamscore - oppscore, 
         season_id = "2018-19", game_id = NA, opp_game_id = NA, 
         team_conf = NA, opp_conf = NA, conf_game = NA, GEI = NA) %>%
  filter(D1 == 2)
teams <- unique(y$team)

### Game IDs
for(i in 1:length(teams)) {
  y[y$team == teams[i],] <- y %>%
    filter(team == teams[i]) %>%
    mutate(game_id = seq(1, sum(team == teams[i]), 1))
}

### Opp Game IDs
for(i in 1:nrow(y)) {
  y$opp_game_id[i] <- get_opp_id(y, i)[1]
}

### Confs
for(i in 1:length(teams)) {
  y$team_conf[y$team == teams[i]] <- get_conf(teams[i])
  y$opp_conf[y$opponent == teams[i]] <- get_conf(teams[i])
}
y$conf_game <- y$team_conf == y$opp_conf
y$reg_season <- (y$month < 3 | y$month >= 11) | (y$month == 3 & y$day <= 10)

################################# Set Weights ##################################
y$weights <- 0
for(i in 1:nrow(y)) {
  w_team <- 1 - (max(c(0, y$game_id[y$team == y$team[i] & !is.na(y$scorediff)])) - y$game_id[i])/
    max(c(0, y$game_id[y$team == y$team[i] & !is.na(y$scorediff)]))
  w_opponent <- 1 - (max(c(0, y$game_id[y$team == y$opponent[i] & !is.na(y$scorediff)])) - y$opp_game_id[i])/
    max(c(1, y$game_id[y$team == y$opponent[i] & !is.na(y$scorediff)]))
  rr <- mean(c(w_team, w_opponent))
  y$weights[i] <- 1/(1 + (0.5^(5 * rr)) * exp(-rr))
}   

############################### Create Model ###################################
lm.hoops <- lm(scorediff ~ team + opponent + location, weights = weights, data = y) 

######################## Point Spread to Win Percentage Model #################
y$predscorediff <- round(predict(lm.hoops, newdata = y), 1)
y$wins[y$scorediff > 0] <- 1
y$wins[y$scorediff < 0] <- 0
glm.pointspread <- glm(wins ~ predscorediff, data = y, family=binomial) 
summary(glm.pointspread)
y$wins[is.na(y$wins)] <- 
  round(predict(glm.pointspread, newdata = y[is.na(y$wins),], type = "response"), 3)

####################  Get Ivy Games For Given Weekend)
filter(y, team_conf == "Ivy", conf_game, month == 2, day %in% c(8,9), location == "H") %>%
  select(year, month, day, team, opponent, location, predscorediff, wins)
